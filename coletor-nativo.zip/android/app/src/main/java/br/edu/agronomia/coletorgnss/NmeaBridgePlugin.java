package br.edu.agronomia.coletorgnss;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * NmeaBridgePlugin
 *
 * Connects directly (raw TCP socket, no browser involved) to the local
 * NMEA TCP server exposed by the GNSS Master app on the same device
 * (usually 127.0.0.1). Every NMEA sentence line received is forwarded
 * to the web layer as a "nmeaLine" event, which is parsed in JavaScript.
 *
 * This intentionally bypasses Android's mock-location mechanism (and the
 * browser's isFromMockProvider() filtering) entirely: it reads the raw
 * receiver stream the same way GNSS Master itself talks to SW Maps.
 */
@CapacitorPlugin(name = "NmeaBridge")
public class NmeaBridgePlugin extends Plugin {

    private ExecutorService executor;
    private Socket socket;
    private final AtomicBoolean running = new AtomicBoolean(false);

    @PluginMethod
    public void connect(PluginCall call) {
        String host = call.getString("host", "127.0.0.1");
        Integer port = call.getInt("port", 9999);

        if (running.get()) {
            disconnectInternal("Reconectando");
        }

        executor = Executors.newSingleThreadExecutor();
        running.set(true);

        final String fHost = host;
        final int fPort = port;

        executor.submit(() -> {
            try {
                socket = new Socket();
                socket.connect(new InetSocketAddress(fHost, fPort), 8000);
                socket.setSoTimeout(15000);

                bridge.getActivity().runOnUiThread(() -> call.resolve());
                emitConnectionState(true, null);

                BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                String line;
                while (running.get() && (line = reader.readLine()) != null) {
                    final String fLine = line;
                    JSObject data = new JSObject();
                    data.put("line", fLine);
                    notifyListeners("nmeaLine", data);
                }
            } catch (Exception e) {
                bridge.getActivity().runOnUiThread(() -> call.reject("Falha ao conectar: " + e.getMessage(), e));
            } finally {
                emitConnectionState(false, running.get() ? "Conexão encerrada pelo receptor" : "Desconectado");
                running.set(false);
            }
        });
    }

    @PluginMethod
    public void disconnect(PluginCall call) {
        disconnectInternal("Desconectado pelo usuário");
        call.resolve();
    }

    @PluginMethod
    public void getStatus(PluginCall call) {
        JSObject data = new JSObject();
        data.put("connected", running.get());
        call.resolve(data);
    }

    private void disconnectInternal(String reason) {
        running.set(false);
        try {
            if (socket != null) {
                socket.close();
            }
        } catch (Exception ignored) {
        }
        if (executor != null) {
            executor.shutdownNow();
        }
        emitConnectionState(false, reason);
    }

    private void emitConnectionState(boolean connected, String reason) {
        JSObject data = new JSObject();
        data.put("connected", connected);
        if (reason != null) {
            data.put("reason", reason);
        }
        notifyListeners("connectionState", data);
    }

    @Override
    protected void handleOnDestroy() {
        disconnectInternal("App encerrado");
        super.handleOnDestroy();
    }
}
