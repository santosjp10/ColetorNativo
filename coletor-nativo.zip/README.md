# Coletor de Campo GNSS — app Android nativo

Este projeto resolve a limitação do app em HTML puro: em vez de depender da
localização simulada (mock location) do Android, que o navegador filtra por
segurança, este app **conecta direto, via socket TCP, no servidor NMEA local
do GNSS Master** (o mesmo mecanismo que a documentação do GNSS Master descreve
para a integração nativa com o SW Maps). Os dados de latitude, longitude,
altitude, tipo de fixação (RTK Fix / Float / DGPS / autônomo) e HDOP são lidos
diretamente das sentenças NMEA (GGA), sem passar pelo Android LocationManager.

Você **não precisa instalar Android Studio nem nada no seu computador**. O
GitHub compila o `.apk` para você, na nuvem, gratuitamente. Basta subir esta
pasta para um repositório do GitHub.

## Passo a passo (sem usar terminal)

### 1. Crie uma conta gratuita no GitHub (se ainda não tiver)
Acesse https://github.com/signup

### 2. Crie um repositório novo
- Clique no `+` no canto superior direito → **New repository**.
- Dê um nome, por exemplo `coletor-gnss`.
- Marque como **Private** (recomendado) ou Public, como preferir.
- Clique em **Create repository**. Não adicione README/gitignore nessa tela.

### 3. Envie os arquivos deste projeto
- Na página do repositório recém-criado, clique em **uploading an existing file**
  (ou "Add file" → "Upload files").
- Arraste **todo o conteúdo desta pasta** (menos a pasta `node_modules`, que não
  existe aqui pois já foi removida) para a área de upload do GitHub.
  - Isso inclui: `www/`, `android/`, `.github/`, `capacitor.config.json`,
    `package.json`, `.gitignore`, este `README.md`.
- Role até o final da página e clique em **Commit changes**.

### 4. Aguarde a compilação automática
- Vá até a aba **Actions** no topo do repositório.
- Você verá um workflow chamado "Build APK" rodando (ícone amarelo = em
  andamento, verde = concluído, vermelho = falhou).
- Isso leva de 3 a 8 minutos na primeira vez.

### 5. Baixe o APK compilado
- Quando o workflow terminar com o ícone verde, clique nele.
- Role até a seção **Artifacts** no final da página.
- Baixe `coletor-gnss-debug-apk` (é um `.zip` contendo o `app-debug.apk`).
- Transfira o `.apk` para o seu celular (Google Drive, e-mail, cabo USB) e
  toque nele para instalar. O Android vai pedir para permitir "instalar apps
  de fontes desconhecidas" — autorize apenas para este arquivo.

### 6. Configurar o GNSS Master para expor o servidor TCP local
No GNSS Master, abra as configurações de **Data Output Stream** e configure a
saída como **TCP Server** (não precisa mais habilitar Mock Location). Anote a
porta configurada — você vai digitar essa mesma porta dentro do app.

### 7. Usar o app
- Abra o **Coletor GNSS** no celular.
- Toque em "Conexão com o GNSS Master (TCP)", confirme o IP `127.0.0.1` e a
  porta configurada no GNSS Master, e toque em **Conectar**.
- A leitura de posição, fixação (RTK Fix/Float/DGPS) e HDOP deve aparecer no
  painel. Colete pontos e exporte o CSV normalmente, como já fazia na versão
  web.

## Sempre que eu (Claude) mudar algo no código
Basta repetir o passo 3 (subir os arquivos alterados) — o GitHub recompila
automaticamente e você baixa um novo `.apk` no passo 5.

## Estrutura do projeto
- `www/index.html` — todo o app (interface, formulário, exportação CSV,
  parser de NMEA). Só usa APIs padrão de navegador, sem build step.
- `android/app/src/main/java/.../NmeaBridgePlugin.java` — plugin nativo que
  abre o socket TCP e repassa cada linha NMEA para o JavaScript.
- `android/app/src/main/java/.../MainActivity.java` — registra o plugin.
- `.github/workflows/build-apk.yml` — a receita que o GitHub usa para
  compilar o `.apk` automaticamente, sem você precisar instalar nada.
